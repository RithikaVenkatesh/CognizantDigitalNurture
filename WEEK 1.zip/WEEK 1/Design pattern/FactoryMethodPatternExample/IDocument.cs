namespace FactoryMethodPatternExample
{
    public interface IDocument
    {
        void Open();
    }
}
